
package pedidofarmaciaapp;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.Date;
import javax.swing.SpinnerDateModel;

public class PedidoFarmaciaApp {

    public static void main(String[] args) {
        // Ejecuta la GUI en un hilo de eventos de Swing
        SwingUtilities.invokeLater(() -> new PedidoFarmaciaGUI());
    }
}
