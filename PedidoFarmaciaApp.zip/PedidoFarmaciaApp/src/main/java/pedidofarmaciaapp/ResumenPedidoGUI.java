package pedidofarmaciaapp;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.Date;
import javax.swing.SpinnerDateModel;

// Clase para la ventana de resumen del pedido
class ResumenPedidoGUI extends JFrame {
    public ResumenPedidoGUI(Pedido pedido) {
        setTitle("Resumen del Pedido");
        setSize(400, 250);
        setLayout(new GridLayout(6, 1));
        
        add(new JLabel("Pedido al distribuidor: " + pedido.distribuidor));
        add(new JLabel(pedido.cantidad + " unidades del " + pedido.tipo + " " + pedido.medicamento));
        add(new JLabel("Para la sucursal: " + pedido.sucursal));
        add(new JLabel("Fecha del Pedido: " + pedido.fechaPedido));
        
        JButton btnCerrar = new JButton("Cerrar");
        btnCerrar.addActionListener(e -> dispose());
        add(btnCerrar);
        
        setVisible(true);
    }
}

