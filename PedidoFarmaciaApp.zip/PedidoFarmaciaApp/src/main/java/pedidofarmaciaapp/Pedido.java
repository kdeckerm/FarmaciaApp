package pedidofarmaciaapp;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.Date;
import javax.swing.SpinnerDateModel;

// Clase que representa un Pedido
class Pedido {
    String medicamento, tipo, distribuidor, sucursal, fechaPedido;
    int cantidad;

    public Pedido(String medicamento, String tipo, int cantidad, String distribuidor, String sucursal, String fechaPedido) {
        this.medicamento = medicamento;
        this.tipo = tipo;
        this.cantidad = cantidad;
        this.distribuidor = distribuidor;
        this.sucursal = sucursal;
        this.fechaPedido = fechaPedido;
    }
}

